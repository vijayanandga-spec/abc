
import os

os.environ["S247_LICENSE_KEY"] = "eu_chandhravadanan"