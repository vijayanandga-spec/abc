default_app_config = "apminsight.contrib.django.apps.ApminsightConfig"
